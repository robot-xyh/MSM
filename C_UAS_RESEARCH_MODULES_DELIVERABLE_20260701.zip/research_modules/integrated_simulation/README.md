# Integrated Simulation

This package runs an offline 5v5 point-mass integration of D1-D6. It is an
evaluation harness only: it writes synthetic logs, D4 arbitration records, D6
metrics, and plots. It does not include hardware drivers, real vehicle control,
automatic disposition, or authorization bypasses.

## Modules

- D1 fuses delayed radar, acoustic bearing, and EO pixel observations into
  covariance-carrying tracks.
- D2 converts D1 tracks into stable global IDs using GNN/Hungarian association.
- D3 builds versioned rolling assignments with hysteresis.
- D4 evaluates passive failover and active degradation using center health,
  secondary-node availability, D1/D2/D3 uncertainty, and D5 terminal evidence.
- D5 performs conservative terminal visual association without rewriting
  center-owned `global_track_id`.
- D6 consumes logs and produces metrics, CSV tables, Markdown reports, and
  charts.
- D7 simulates offline proportional navigation after assignment: radar-track
  midcourse PN followed by visual LOS terminal PN.

## Commands

```bash
python3 research_modules/integrated_simulation/run_episode.py --scenario nominal_5v5
python3 research_modules/integrated_simulation/run_batch.py
python3 research_modules/integrated_simulation/generate_global_process_gif.py
```

Outputs are written under `research_modules/integrated_simulation/outputs/`.

The GIF generator writes `global_process_2d.gif`, an explanatory 2D animation
showing multi-sensor observations, fused tracks, data association, central
assignment, radar PN midcourse guidance, secondary-node reassignment, and
visual PN terminal guidance.
