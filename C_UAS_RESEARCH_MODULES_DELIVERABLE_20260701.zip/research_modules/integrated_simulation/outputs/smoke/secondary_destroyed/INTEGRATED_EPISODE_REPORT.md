# 集成离线评估报告 - secondary_destroyed

本报告由离线记录或合成日志生成。
它不提供实时决策、火控参数、毁伤逻辑、自动处置动作或绕过人工授权的流程。

- Episode 数量: 1
- 随机种子范围: 9

## 1. 汇总表

| 指标 | 均值 | 标准差 | 95% CI 下界 | 95% CI 上界 | 中位数 | P05 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| detection_probability | 1 | 0 | 1 | 1 | 1 | 1 | 1 |
| false_alarm_rate | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| missed_detection_rate | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| track_rmse | 26.8283 | 0 | 26.8283 | 26.8283 | 26.8283 | 26.8283 | 26.8283 |
| track_continuity | 1 | 0 | 1 | 1 | 1 | 1 | 1 |
| id_switch_count | 4 | 0 | 4 | 4 | 4 | 4 | 4 |
| duplicate_assignment_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| unassigned_high_threat_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| failover_time | 1 | 0 | 1 | 1 | 1 | 1 | 1 |
| consensus_rounds | 6 | 0 | 6 | 6 | 6 | 6 | 6 |
| degraded_completion_rate | 1 | 0 | 1 | 1 | 1 | 1 | 1 |
| terminal_association_accuracy | 1 | 0 | 1 | 1 | 1 | 1 | 1 |
| terminal_id_switch_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| ambiguous_fov_event_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| friend_overlap_hold_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| time_to_terminal_lock | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| constraint_violation_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| human_override_count | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## 2. 图表与曲线

![探测指标图](plots/detection_metrics.png)

![跟踪指标图](plots/tracking_metrics.png)

![分配指标图](plots/assignment_metrics.png)

![降级指标图](plots/degradation_metrics.png)

![末端指标图](plots/terminal_metrics.png)

![安全指标图](plots/safety_metrics.png)

![关键指标分布图](plots/selected_metric_distributions.png)

## 3. 解读说明

- 探测、跟踪、分配、降级、末端配准和安全指标分开报告，避免单一命中率掩盖问题。
- 计数类指标应与比例类指标一起检查，少量但严重的安全事件可能被总体成功率掩盖。
- 偏态或长尾指标在形成正式结论前，应使用 bootstrap 或非参数方法复核。
