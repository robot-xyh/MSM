"""D7 offline proportional guidance research module."""

from .models import (
    GuidanceCommand,
    GuidanceConfig,
    GuidanceMode,
    GuidanceRecord,
    GuidanceState,
)
from .pn import compute_pn_command, compute_proportional_navigation_command
from .simulator import simulate_guidance_episode, summarize_guidance_records

__all__ = [
    "GuidanceCommand",
    "GuidanceConfig",
    "GuidanceMode",
    "GuidanceRecord",
    "GuidanceState",
    "compute_pn_command",
    "compute_proportional_navigation_command",
    "simulate_guidance_episode",
    "summarize_guidance_records",
]
